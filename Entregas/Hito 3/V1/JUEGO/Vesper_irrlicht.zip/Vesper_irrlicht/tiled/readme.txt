1	-	gris			-	PARED
2	-	amarillo		-	ALARMA
3	-	amarillo huevo	-	MONEDA
4	-	rosa			-	JUGADOR
5	-	marron			-	PALA
6	-	gris claro		-	PIEDRA
7	-	rojo			-	ENEMIGO
8	-	verde			-	LLAVE
9	-	azul			-	FUENTE
10	-	r. naranja		-	BOTIQUIN
11	-	marron oscuro	-	PUERTA
12	-	morado			-	COMIDA
13	-	verde oscuro	-	CESPED
14	-	verde + oscuro	-	REHEN
15	-	azul turquesa 	-	ESCOPETA (SUPERSOCKER)
16	-	carne 		-	LANZACARAMELOS
17	-	azul clarito	-	GLOBO DE AGUA
18 	-	rosa clarito 	-	CHICLE
19 	-	verde clarito	-	bomba humo
20 	- 	marrón rojizo	-	arbustos delimitan mapa



{ 1		,	""					,	accion1		},
{ 2		,	"3d/alarmita.jpg"	,	accion2		},
{ 3		,	"3d/moneda.jpg"		,	accion3		},
{ 4		,	"3d/texture.png"	,	accion4		},
{ 5		,	"3d/pala.jpg"		,	accion5		},
{ 6		,	"3d/piedra.jpg"		,	accion6		},
{ 7		,	"3d/naranja.jpg"	,	accion7		},
{ 8		,	"3d/llave.jpg"		,	accion8		},
{ 9		,	"3d/fuenten.jpg"	,	accion9		},
{ 10	,	"3d/botiquin.jpg"	,	accion10	},
{ 11	,	"3d/puerta.jpg"		,	accion11	},
{ 12	,	"3d/pizza.jpg"		,	accion12	},
{ 13	,	""					,	accion13	},
{ 14	,	""					,	accion14	},
{ 15	,	“3d/letraE.png”		,	accion15	},
{ 16	,	“3d/letraL.png”		,	accion16	},
{ 17	,	“3d/globoagua.png”	,	accion17	},
{ 18	,	“3d/chicle.png”		,	accion18	},
{ 19	,	“3d/bombahumo.png”	,	accion19	},

GameObject* accion1(){
	
}