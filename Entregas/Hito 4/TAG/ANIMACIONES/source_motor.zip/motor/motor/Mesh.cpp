
#include "Mesh.hpp"
#include "Shader.h"

Mesh::Mesh(Vertex *verts, GLuint *inds, Texture **texs, GLint numV, GLint numI, GLint numT){
	vertices = verts;
	indices = inds;
	texturas = texs;
	numVertices = numV;
	numIndices = numI;
	numTexturas = numT;
	setupMesh();
}

Mesh::~Mesh(){
	delete[] vertices;
	delete[] indices;
	delete[] texturas;
}

void Mesh::Draw(Shader* shader, Texture* textura){
	
	//TO DO: provisional
	glUniform1f(glGetUniformLocation(shader->Program, "shininess"), 1.0f);
	glUniform1i(glGetUniformLocation(shader->Program, "normales"), 0);
	
	GLuint diffuseNr = 1;
	GLuint specularNr = 1;
	GLuint normalNr = 1;
	
	if(textura != nullptr){
		glActiveTexture(GL_TEXTURE0);
		glUniform1f(glGetUniformLocation(shader->Program, "texture_diffuse1"), 0);
		glBindTexture(GL_TEXTURE_2D, textura->id);
	}else{
		
		for(GLuint i = 0; i < numTexturas; i++){
		
			// activamos la textura antes de linkarla
			glActiveTexture(GL_TEXTURE0 + i);
//			glActiveTexture(GL_TEXTURE0);
		
			// recogemos el numero de la textura
			std::stringstream ss;
			std::string number;
			std::string name = texturas[i]->type;
			
			if(name == "texture_diffuse")
				// cambiamos de GLuint a stream
				ss << diffuseNr++;
			else if(name == "texture_specular")
				// cambiamos de GLuint a stream
				ss << specularNr++;
			else if(name == "texture_normal"){
				ss << normalNr++;
				glUniform1i(glGetUniformLocation(shader->Program, "normales"), 1);
			}
			number = ss.str();
			glUniform1i(glGetUniformLocation(shader->Program,(name + number).c_str()), i);
			glBindTexture(GL_TEXTURE_2D, texturas[i]->id);
		}
	}

	glActiveTexture(GL_TEXTURE0);
	
	// dibujamos el mesh
	glBindVertexArray(this->VAO);
	glDrawElements(GL_TRIANGLES, numIndices, GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);
	
	// liberamos la memoria de las texturas
	for (GLuint i = 0; i < numTexturas; i++){
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, 0);
	}
	glActiveTexture(GL_TEXTURE0);
}

void Mesh::setupMesh(){
	//generamos el Vertex Array Object
	glGenVertexArrays(1, &this->VAO);
	glGenBuffers(1, &this->VBO);
	glGenBuffers(1, &this->EBO);
	
	//linkamos el VAO
	glBindVertexArray(this->VAO);
	
	//linkamos el buffer GL_ARRAY_BUFFER al puntero VBO
	glBindBuffer(GL_ARRAY_BUFFER, this->VBO);
	
	//copiamos los datos de los vertices a buffer GL_ARRAY_BUFFER
	glBufferData(GL_ARRAY_BUFFER, numVertices * sizeof(Vertex), &vertices[0], GL_STATIC_DRAW);
	
	//linkamos el array de elementos al EBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, this->EBO);
	
	//copiamos los indices en el array de elementos
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, numIndices * sizeof(GLuint), &indices[0], GL_STATIC_DRAW);
	
	/*
	 * aqui le decimos a OpenGL como interpretar el buffer de vertices cuando tenga que dibujar
	 * el primer parametro es el indice del vertice que queremos configurar
	 * el segundo es el numero de ejes que contiene cada vertice, 1 2 3 o 4
	 * el tercero especifica el tipo de dato que vamos a manejar
	 * el cuarto indica si queremos normalizar los valores o no
	 * el quinto especifica el tamaño de que tiene cada vertice en el buffer, ahora son 3 floats
	 * el sexto es un puntero a la posicion que queremos empezar la figura, esto sirve para cuando tengamos mas de uno
	 * en la otra funcion activamos los atributos de vertices ya que estan desactivados por defecto
	 */
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)0);
	
	//aqui pasamos las normales
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, Normal));
	
	// atributos de las texturas
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, TexCoords));
	
	//atributos de las tangentes
	glEnableVertexAttribArray(3);
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, Tangents));
	
	//atributos de las bitangentes
	glEnableVertexAttribArray(4);
	glVertexAttribPointer(4, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, Bitangents));
	
	//deslinkamos el VAO por seguridad
	glBindVertexArray(0);
}




