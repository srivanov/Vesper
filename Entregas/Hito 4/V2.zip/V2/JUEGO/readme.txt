CONTROLES

W —> el player se mueve hacia delante 
A —> el player se mueve hacia la izquierda 
D —> el player se mueve hacia la derecha 
S —> el player se mueve hacia detrás
Esc —> se pausa el juego
TAB —> sirve para cambiar de arma 
Q —> cambia entre las llaves que lleva el personaje 
Click izquierdo —> Disparar
E -> 