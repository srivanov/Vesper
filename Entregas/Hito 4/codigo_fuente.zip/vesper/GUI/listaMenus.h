//
//  listaMenus.h
//  vesper
//
//  Created by Catherine Castrillo González on 29/03/17.
//  Copyright © 2017 Stoycho Ivanov Atanasov. All rights reserved.
//

#ifndef listaMenus_h
#define listaMenus_h

#include "PausaLayout.hpp"
#include "MenuPrincipalLayout.hpp"
#include "CreditosLayout.hpp"
#include "OpcionesLayout.hpp"
#include "ElegirPersonaje.hpp"
#include "HUDLayout.hpp"


#endif /* listaMenus_h */
