
#include "blindada.hpp"

blindada::blindada(){
	
}

blindada::~blindada(){
	
}

void blindada::update(){
	
}
