
#ifndef armasArrojadizas_hpp
#define armasArrojadizas_hpp

#include <stdio.h>
#include "component.hpp"

class armasArrojadizas : public component {
public:
    armasArrojadizas();
    ~armasArrojadizas();
	void update();
	
};
#endif /* armasArrojadizas_hpp */
