
#ifndef puertaInterface_hpp
#define puertaInterface_hpp

#include <stdio.h>

class puertaInterface{
public:
	virtual bool abre() = 0;
};

#endif /* puertaInterface_hpp */
