
#include "conPuzzle.hpp"

conPuzzle::conPuzzle(){
	
}

conPuzzle::~conPuzzle(){
	
}

void conPuzzle::update(){
	
}
