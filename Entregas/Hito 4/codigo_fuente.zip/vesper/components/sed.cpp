
#include "sed.hpp"

sed::sed(){
    
}

sed::~sed(){
    
}

void sed::update(){
	
}
