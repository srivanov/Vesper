
#include "chirriante.hpp"

chirriante::chirriante(){
	
}

chirriante::~chirriante(){
	
}

void chirriante::update(){
	
}

bool chirriante::abre(){    
	return true;
}
