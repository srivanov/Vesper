
#include "salud.hpp"

salud::salud(){
	
}

salud::~salud(){
	
}

void salud::update(){
	
}
