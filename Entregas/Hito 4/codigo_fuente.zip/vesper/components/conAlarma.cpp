
#include "conAlarma.hpp"

conAlarma::conAlarma(){
	
}

conAlarma::~conAlarma(){
	
}

void conAlarma::update(){
	
}
