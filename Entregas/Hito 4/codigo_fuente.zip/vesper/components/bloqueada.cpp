
#include "bloqueada.hpp"

bloqueada::bloqueada(){
	
}

bloqueada::~bloqueada(){
	
}

void bloqueada::update(){
	
}
