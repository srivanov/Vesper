
#include "hambre.hpp"

hambre::hambre(){
    
}

hambre::~hambre(){
    
}

void hambre::update(){
	
}
