
#ifndef conPuzzle_hpp
#define conPuzzle_hpp

#include <stdio.h>
#include "component.hpp"

class conPuzzle : public component{
public:
	conPuzzle();
	~conPuzzle();
	void update();
	
};

#endif /* conPuzzle_hpp */
