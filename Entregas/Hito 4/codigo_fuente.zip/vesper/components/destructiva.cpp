
#include "destructiva.hpp"

destructiva::destructiva(){
	
}

destructiva::~destructiva(){
	
}

void destructiva::update(){
	
}
