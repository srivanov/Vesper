
#include "armasArrojadizas.hpp"

armasArrojadizas::armasArrojadizas(){
    
}

armasArrojadizas::~armasArrojadizas(){
    
}

void armasArrojadizas::update(){
	
}
