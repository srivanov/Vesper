//
//  Arquitecture.hpp
//  Arquitectura
//
//  Created by Gaspar Rodriguez Valero on 18/3/17.
//  Copyright © 2017 Gaspar Rodriguez Valero. All rights reserved.
//

#ifndef Objects_hpp
#define Objects_hpp

// CINEMATICOS

#include "Camera.hpp"
#include "Ground.hpp"

#include "PhysicObjects/AllPhysicsObjects.hpp"

#endif /* Objects_hpp */
