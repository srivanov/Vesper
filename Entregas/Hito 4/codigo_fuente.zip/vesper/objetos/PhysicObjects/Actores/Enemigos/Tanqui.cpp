//
//  Tanqui.cpp
//  Arquitectura
//
//  Created by Gaspar Rodriguez Valero on 21/3/17.
//  Copyright © 2017 Gaspar Rodriguez Valero. All rights reserved.
//

#include "Tanqui.hpp"
