//
//  actores.h
//  vesper
//
//  Created by Gaspar Rodriguez Valero on 9/5/17.
//  Copyright © 2017 Stoycho Ivanov Atanasov. All rights reserved.
//

#ifndef actores_hpp
#define actores_hpp

#include "Enemy.hpp"
#include "Player.hpp"
#include "Rehen.hpp"

#endif /* actores_h */
