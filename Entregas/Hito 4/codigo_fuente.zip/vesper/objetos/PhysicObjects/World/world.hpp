//
//  world.hpp
//  vesper
//
//  Created by Gaspar Rodriguez Valero on 9/5/17.
//  Copyright © 2017 Stoycho Ivanov Atanasov. All rights reserved.
//

#ifndef world_h
#define world_h

#include "Alarm.hpp"
#include "Botiquin.hpp"
#include "Comida.hpp"
#include "Fuente.hpp"
#include "Muro.hpp"
#include "Puerta.hpp"
#include "Decoracion.hpp"

#endif /* world_h */
