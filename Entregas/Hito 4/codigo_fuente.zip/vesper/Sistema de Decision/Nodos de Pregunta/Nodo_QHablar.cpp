//
//  Nodo_QHablar.cpp
//  arquitectura
//
//  Created by Gaspar Rodriguez Valero on 23/2/17.
//  Copyright © 2017 Stoycho Ivanov Atanasov. All rights reserved.
//

#include "Nodo_QHablar.hpp"

short Nodo_QHablar::run(const int &ID){
    //TO DO : CONDICIONES DE CUANDO HABLAR
    /*
     if()
        return runHijos(ID);
     */
    cout << "HABLAR?" << endl;
    return FALLO;
}
