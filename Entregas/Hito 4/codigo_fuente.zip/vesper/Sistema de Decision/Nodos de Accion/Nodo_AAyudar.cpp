//
//  Nodo_AAyudar.cpp
//  arquitectura
//
//  Created by Gaspar Rodriguez Valero on 23/2/17.
//  Copyright © 2017 Stoycho Ivanov Atanasov. All rights reserved.
//

#include "Nodo_AAyudar.hpp"

short Nodo_AAyudar::run(const int &ID){
    cout << "AYUDE" << endl;
    return FUNCIONO;
}
