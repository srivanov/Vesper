La implementación del HUD se puede apreciar nada más ejecutar el juego y darle a jugar.

- En la esquina inferior izquierda se ven las armas con su respectiva munición y puedes ir cambiando de arma pulsando la tecla TAB.
- En la esquina superior izquierda se ve la barra de vida, las monedas y las llaves que van cambiando según vaya cambiando la
vida del jugador, o se vayan cogiendo monedas y llaves.

El HUD está implementado con CEGUI.